if __name__ == "__main__":
    print("Why are you running this file?")