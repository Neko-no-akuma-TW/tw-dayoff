def main():
    print("Why are you running this file?")